# practical-application-sentiment-analysis-deep-learning
Practical application for Sentiment Analysis with Deep Learning
